<?php

// Setup Framework
require_once('framework/setup.php');

// Setup Theme
require_once('lib/setup.php');

?>