<?php if(rvn_get_page_content_size() != 'full'): ?>

  <div id="sidebar">
      <?php rvn_put_sidebar_widget_area(); ?>
  </div>
  <!-- END #sidebar -->
  
<?php endif; ?>